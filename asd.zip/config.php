<?php
        define("DB_HOST", "52.79.79.79");
        define("DB_USER", "root");
        define("DB_PASSWORD", "123123");
        define("DB_NAME", "test");

        define("GOOGLE_API_KEY", "AAAAEaab7j8:APA91bGgwft0G4K0EgtOZihJdMMTg31RxSMZ8Mr_qvx1aKEW0jC3xeqyLE1Lc3l-00PI52EZB3PDmNOF9QZ7AD2c8TwY6vcEr0WBakw_vUJzs-2uOgdetGpeqAVGaDfhdT_GGAH8wflH");

?>